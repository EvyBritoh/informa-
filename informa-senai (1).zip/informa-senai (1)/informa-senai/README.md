# IN-FORMA SENAI (frontend)

HTML + CSS + JavaScript (ES modules). **Sem Node, sem npm, sem build.**

## Como abrir
Os módulos ES exigem um servidor HTTP estático (não funcionam com duplo clique em `file://`). Use qualquer um:
- **VS Code:** extensão *Live Server* → botão direito em `index.html` → *Open with Live Server*
- **Python:** `python3 -m http.server 8000` na pasta do projeto e abra `http://localhost:8000`
- **Hospedagem estática** (GitHub Pages, Apache, Nginx, Django `static`…): basta publicar a pasta.

Rotas usam hash (`#/entrar`, `#/cadastro`, `#/noticias/slug`), então não é preciso configurar fallback de servidor.

## Estrutura
- `src/pages` páginas · `src/components` componentes · `src/layouts` layouts (site, auth, panel)
- `src/services` camada de API · `src/data` dados mockados (notícias, eventos, projetos)
- `src/routes.js` + `src/router.js` rotas · `src/config.js` configuração · `src/styles` CSS · `src/utils` utilitários

## Autenticação (login/cadastro)
Rotas: `#/entrar`, `#/cadastro`, `#/recuperar-senha`. **Não há simulação**: `src/services/authService.js` chama a API real
(`POST {apiBaseUrl}/auth/login`, `/auth/register`, `/auth/forgot-password`; contrato descrito no topo do arquivo, ajuste ao backend).
Enquanto o backend não existir, o usuário vê "Serviço de autenticação indisponível" e nada é redirecionado.
Consequência: o painel (`#/painel`) só abre depois que um login real criar a sessão.

Pendências para ligar ao backend:
1. Definir `apiBaseUrl` em `src/config.js` e implementar os 3 endpoints (respostas de erro: 401/409/422/429).
2. Decidir sessão: token Bearer (hoje guardado em `localStorage`) ou cookie httpOnly + CSRF (recomendado; `credentials:'same-origin'` já está ativo).
3. Se for exigir domínio institucional, preencher `institutionalDomains` em `config.js`; a validação definitiva deve ser do servidor.
4. Trocar os serviços de notícias para a API (`useMock:false`) e imagens em `src/assets/images.js`.
