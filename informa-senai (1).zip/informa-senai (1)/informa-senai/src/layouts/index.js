import {html} from '../utils/dom.js';
import {Header,PanelHeader,mountHeader} from '../components/Header.js';
import {Footer} from '../components/Footer.js';
import {shell} from '../shell.js';

const main=(cls,view)=>html`<main id="conteudo" class="${cls}" tabindex="-1">${view}</main>`;
/** Cada página escolhe um layout via page.layout ('site' por padrão). */
export const layouts={
  site:{render:(view,ctx)=>html`${Header(ctx)}${main('main',view)}${Footer(shell)}`,mount:mountHeader},
  auth:{render:view=>main('auth',view)},
  panel:{render:(view,ctx)=>html`${PanelHeader(ctx)}${main('panel',view)}`,mount:mountHeader}
};
