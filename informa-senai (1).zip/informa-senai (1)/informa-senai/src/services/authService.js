import {config} from '../config.js';
import {http,ApiError} from './http.js';
import {session} from './session.js';
import {users} from '../data/mockRepo.js';

/**
 * Autenticação SEMPRE usa a API real (nunca mock). Contrato esperado (ajuste ao backend definitivo):
 *   POST /auth/login            {email,password}  => 200 {token,user:{id,name,email,role}}
 *   POST /auth/register         {email,password}  => 201 {token,user} ou 201 sem corpo útil
 *   POST /auth/forgot-password  {email}           => 202
 * Mensagens exibidas ao usuário são fixas: nada do que o servidor devolve é mostrado.
 * Cookies de sessão (ex.: Django) funcionam com credentials 'same-origin'; CSRF fica a cargo do backend.
 */
const UNAVAILABLE='Serviço de autenticação indisponível no momento. Tente novamente mais tarde.';
const MESSAGES={
  login:{401:'E-mail ou senha incorretos.',400:'E-mail ou senha incorretos.',422:'E-mail ou senha incorretos.',403:'Acesso não autorizado para esta conta.',429:'Muitas tentativas. Aguarde alguns minutos.'},
  register:{409:'Este e-mail já possui cadastro.',400:'Verifique os dados informados e tente novamente.',422:'Verifique os dados informados e tente novamente.',429:'Muitas tentativas. Aguarde alguns minutos.'},
  reset:{429:'Muitas tentativas. Aguarde alguns minutos.'}
};
async function request(kind,path,body){
  try{return await http(path,{method:'POST',body});}
  catch(err){
    const s=err?.status;
    // sem status (rede/JSON inválido) ou rota inexistente/servidor sem a API => backend não conectado
    if(!s||[404,405,501,502,503,504].includes(s))throw new ApiError(503,UNAVAILABLE);
    throw new ApiError(s,MESSAGES[kind][s]||'Não foi possível concluir a operação. Tente novamente.');
  }
}
const publicUser=u=>({id:u.id,name:u.name,email:u.email,role:u.role});
function start(res){
  if(!res?.token||!res?.user)return null;
  session.set({token:res.token,user:publicUser(res.user)});return res.user;
}
export const isValidEmail=e=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());
export const isInstitutionalEmail=e=>config.institutionalDomains.length===0||config.institutionalDomains.some(d=>e.trim().toLowerCase().endsWith('@'+d));
export const getCurrentUser=()=>session.get()?.user||null;
export const logout=()=>session.clear();
export async function login(email,password){
  const user=start(await request('login','/auth/login',{email:email.trim(),password}));
  if(!user)throw new ApiError(503,UNAVAILABLE); // resposta sem sessão válida: nunca tratar como sucesso
  return user;
}
/** Retorna o usuário se a API já abrir sessão no cadastro; caso contrário null (usuário deve entrar). */
export const register=async(email,password)=>start(await request('register','/auth/register',{email:email.trim(),password}));
export const requestPasswordReset=email=>request('reset','/auth/forgot-password',{email:email.trim()});
/** Autores exibidos no rodapé (dado público; mock até existir GET /authors). */
export const getContributors=async()=>users().filter(u=>u.role==='escritor').map(({id,name,handle})=>({id,name,handle}));
