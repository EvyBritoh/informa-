import {http,call} from './http.js';
import {eventsRepo} from '../data/mockRepo.js';
export const getEvents=()=>call(()=>eventsRepo.list(),()=>http('/events'));
export const getUpcomingEvents=(limit=3)=>call(()=>eventsRepo.upcoming(limit),()=>http('/events',{params:{upcoming:true,limit}}));
export const createEvent=data=>call(()=>eventsRepo.create(data),()=>http('/events',{method:'POST',body:data}));
export const updateEvent=(id,data)=>call(()=>eventsRepo.update(id,data),()=>http(`/events/${id}`,{method:'PATCH',body:data}));
export const deleteEvent=id=>call(()=>eventsRepo.remove(id),()=>http(`/events/${id}`,{method:'DELETE'}));
