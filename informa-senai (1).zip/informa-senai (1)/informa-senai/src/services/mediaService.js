import {config} from '../config.js';
import {http,call,ApiError} from './http.js';
import {compressImage} from '../utils/image.js';
/** Retorna a URL da imagem. Real: POST /media (multipart) => {url}. */
export function uploadImage(file){
  if(!file.type.startsWith('image/'))return Promise.reject(new ApiError(400,'Selecione um arquivo de imagem.'));
  if(file.size>config.maxImageBytes)return Promise.reject(new ApiError(400,'A imagem excede 5 MB.'));
  return call(()=>compressImage(file),()=>{const f=new FormData();f.append('file',file);return http('/media',{method:'POST',body:f}).then(r=>r.url);});
}
