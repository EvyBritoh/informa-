import {http,call} from './http.js';
import {newsRepo} from '../data/mockRepo.js';
/** @returns {Promise<import('../types.js').Paginated>} GET /news?page&type&category&q */
export const getNews=(params={})=>call(()=>newsRepo.list(params),()=>http('/news',{params}));
export const searchNews=(q,params={})=>getNews({...params,q});
export const getFeaturedNews=(limit=3)=>call(()=>newsRepo.list({featured:true,pageSize:limit}).items,()=>http('/news',{params:{featured:true,pageSize:limit}}).then(r=>r.items));
export const getNewsBySlug=slug=>call(()=>newsRepo.bySlug(slug),()=>http(`/news/slug/${encodeURIComponent(slug)}`));
export const getNewsById=id=>call(()=>newsRepo.byId(id),()=>http(`/news/${id}`));
export const getRelatedNews=(news,limit=3)=>call(()=>newsRepo.related(news,limit),()=>http(`/news/${news.id}/related`,{params:{limit}}));
export const registerView=id=>call(()=>newsRepo.view(id),()=>http(`/news/${id}/views`,{method:'POST'})).catch(()=>{});
/** Notícias do usuário logado (admin vê todas). GET /me/news?status= */
export const getManagedNews=(params={})=>call(()=>newsRepo.managed(params),()=>http('/me/news',{params}));
export const createNews=data=>call(()=>newsRepo.create(data),()=>http('/news',{method:'POST',body:data}));
export const updateNews=(id,data)=>call(()=>newsRepo.update(id,data),()=>http(`/news/${id}`,{method:'PATCH',body:data}));
/** decision: 'approve' | 'revision' (+ feedback). POST /news/:id/review */
export const reviewNews=(id,payload)=>call(()=>newsRepo.review(id,payload),()=>http(`/news/${id}/review`,{method:'POST',body:payload}));
export const deleteNews=id=>call(()=>newsRepo.remove(id),()=>http(`/news/${id}`,{method:'DELETE'}));
export const getDashboardStats=()=>call(()=>newsRepo.stats(),()=>http('/me/stats'));
export const getSiteStats=()=>call(()=>newsRepo.site(),()=>http('/stats'));
