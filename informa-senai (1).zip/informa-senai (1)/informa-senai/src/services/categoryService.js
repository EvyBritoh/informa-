import {http,call} from './http.js';
import {categoriesRepo} from '../data/mockRepo.js';
export const getCategories=()=>call(()=>categoriesRepo.list(),()=>http('/categories'));
export const getCategoryBySlug=slug=>call(()=>categoriesRepo.bySlug(slug),()=>http(`/categories/${slug}`));
