import {http,call} from './http.js';
import {projectsRepo} from '../data/mockRepo.js';
export const getProjects=(params={})=>call(()=>projectsRepo.list(params),()=>http('/projects',{params}));
export const getProjectBySlug=slug=>call(()=>projectsRepo.bySlug(slug),()=>http(`/projects/${slug}`));
