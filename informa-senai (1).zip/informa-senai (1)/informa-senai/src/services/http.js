import {config} from '../config.js';
import {session} from './session.js';
export class ApiError extends Error{constructor(status,message){super(message);this.status=status;}}
/** Cliente HTTP único. Backend esperado: JSON, Bearer token, erros {message}. */
export async function http(path,{method='GET',body,params={}}={}){
  const url=new URL(config.apiBaseUrl+path,location.origin);
  Object.entries(params).forEach(([k,v])=>v!=null&&v!==''&&url.searchParams.set(k,Array.isArray(v)?v.join(','):v));
  const token=session.get()?.token;
  const res=await fetch(url,{method,credentials:'same-origin',headers:{...(body instanceof FormData?{}:{'Content-Type':'application/json'}),...(token&&{Authorization:`Bearer ${token}`})},
    body:body instanceof FormData?body:body&&JSON.stringify(body)});
  if(!res.ok)throw new ApiError(res.status,(await res.json().catch(()=>({}))).message||res.statusText);
  return res.status===204?null:res.json();
}
// Roda a implementação mock ou real conforme config.useMock.
export const call=(mockFn,realFn)=>config.useMock?Promise.resolve().then(mockFn):realFn();
