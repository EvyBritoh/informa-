import {config} from '../config.js';
const KEY=config.storagePrefix+'session';
export const session={
  get(){try{return JSON.parse(localStorage.getItem(KEY));}catch{return null;}},
  set(v){try{localStorage.setItem(KEY,JSON.stringify(v));}catch{/* sem storage */}},
  clear(){try{localStorage.removeItem(KEY);}catch{/* sem storage */}}
};
