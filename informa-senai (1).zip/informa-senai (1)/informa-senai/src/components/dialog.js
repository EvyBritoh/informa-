import {html,raw} from '../utils/dom.js';
/** Diálogo nativo <dialog>. Resolve {value,data} ao fechar (value '' = Esc). */
export function openDialog({title,body,actions}){
  return new Promise(resolve=>{
    const d=document.createElement('dialog');d.className='dialog';
    d.innerHTML=html`<form method="dialog"><h2>${title}</h2><div class="dialog__body">${body}</div>
      <div class="dialog__actions">${actions.map(a=>html`<button class="btn btn--${a.variant||'secondary'}" value="${a.value}" ${a.skipValidation?raw('formnovalidate'):''}>${a.label}</button>`)}</div></form>`.s;
    d.addEventListener('close',()=>{resolve({value:d.returnValue,data:Object.fromEntries(new FormData(d.querySelector('form')))});d.remove();});
    document.body.append(d);d.showModal();
  });
}
export const confirmDialog=(title,text,label='Confirmar')=>openDialog({title,body:html`<p>${text}</p>`,
  actions:[{label:'Cancelar',value:'cancel',skipValidation:true},{label,value:'ok',variant:'danger'}]}).then(r=>r.value==='ok');
