import {raw} from '../utils/dom.js';
const P={
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  close:'<path d="M6 6l12 12M18 6 6 18"/>',
  eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  'eye-off':'<path d="M3 3l18 18M10.6 6.2A9.8 9.8 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.7C3.9 8.4 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.2-1"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  'arrow-left':'<path d="M19 12H5m6-6-6 6 6 6"/>',
  upload:'<path d="M12 16V4m-5 5 5-5 5 5M4 20h16"/>'
};
export const Icon=(name,size=20)=>raw(`<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name]}</svg>`);
