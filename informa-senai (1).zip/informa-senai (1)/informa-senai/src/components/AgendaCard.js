import {html,$,formatDate} from '../utils/dom.js';
import {buildIcs,downloadFile} from '../utils/ics.js';

const short=d=>formatDate(d,{day:'2-digit',month:'short'}).replace(/\./g,'').replace(' de ',' ');
export const AgendaCard=({events})=>html`
<aside class="agenda" aria-labelledby="agenda-title">
  <h2 id="agenda-title">Agenda da semana</h2>
  ${events.length>0?html`
    <ul class="agenda__list">${events.map(e=>html`<li><time class="agenda__date" datetime="${e.date}">${short(e.date)}</time><span>${e.title}</span></li>`)}</ul>
    <button class="btn btn--link" type="button" data-action="save-agenda">Clique para salvar na agenda</button>`
  :html`<p class="agenda__empty">Nenhum evento agendado por enquanto.</p>`}
</aside>`;
export function mountAgenda(root,events){
  $(root,'[data-action=save-agenda]')?.addEventListener('click',()=>downloadFile('agenda-in-forma-senai.ics',buildIcs(events),'text/calendar'));
}
