import {html} from '../utils/dom.js';
import {Button} from './ui.js';

// Texto institucional fixo e igual em login, cadastro e recuperação (painel único, sem duplicação).
const PANEL={title:'IN-FORMA SENAI',text:'Acesse sua conta para publicar artigos, acompanhar métricas de leitura e interagir com a comunidade acadêmica.'};

const InstitutionalPanel=()=>html`
<aside class="auth__panel" aria-labelledby="auth-panel-title">
  <h2 id="auth-panel-title">${PANEL.title}</h2>
  <p>${PANEL.text}</p>
  <img src="./src/assets/security.svg" width="480" height="340" alt="Ilustração de uma janela de navegador protegida por um escudo com cadeado, representando acesso seguro à conta">
</aside>`;

/** Separador "— texto —" seguido de botão de navegação entre login e cadastro. */
export const AuthSwitch=({text,label,href})=>html`
<div class="auth__switch"><p class="auth__sep"><span>${text}</span></p>${Button({label,href,variant:'secondary'})}</div>`;

/** Desktop: [formulário] | [painel]. Abaixo de 768px o painel e a divisória deixam de existir (CSS). */
export const AuthShell=({heading,children})=>html`
<div class="auth__card">
  <section class="auth__form-area" aria-labelledby="auth-title">
    <div class="auth__form-box"><h1 id="auth-title">${heading}</h1>${children}</div>
  </section>
  ${InstitutionalPanel()}
</div>`;
