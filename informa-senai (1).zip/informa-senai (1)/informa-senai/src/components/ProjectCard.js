import {html} from '../utils/dom.js';
import {resolveImage} from '../assets/images.js';
import {Button} from './ui.js';
export const ProjectCard=(p,{level=3}={})=>html`
<article class="card card--project">
  <div class="card__media"><img src="${resolveImage(p.image)}" alt="" width="640" height="360" loading="lazy" decoding="async"></div>
  <div class="card__body">
    <p class="card__kind">${p.kind}</p>
    <p class="card__meta"><span>Por ${p.author.name}</span></p>
    <p class="card__course">${p.course}</p>
    <h${level} class="card__title">${p.title}</h${level}>
    ${Button({label:'Acessar projeto',href:`/projetos/${p.slug}`,variant:'secondary'})}
  </div>
</article>`;
