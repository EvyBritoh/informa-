import {html,raw,$,todayLong,initials} from '../utils/dom.js';
import {config} from '../config.js';
import {ROLES} from '../types.js';
import {logout} from '../services/authService.js';
import {navigate} from '../router.js';
import {Icon} from './icons.js';
import {SearchBar} from './ui.js';

const active=(href,path)=>href==='/'?path==='/':path.startsWith(href);
const Logo=cls=>html`<a class="logo ${cls}" href="/" aria-label="${config.siteName} — página inicial">IN-FORMA <span>SENAI</span></a>`;
export const Brand=Logo;

export const Header=({path,user})=>html`
<header class="masthead">
  <div class="container masthead__top">
    <p>${config.edition}</p>
    <p>${config.city} | <time datetime="${new Date().toISOString().slice(0,10)}">${todayLong()}</time></p>
  </div>
  <div class="container masthead__brand">
    ${Logo('')}
    <div class="masthead__actions">
      ${user?html`<a class="btn btn--ghost btn--sm" href="/painel">Meu painel</a><button class="btn btn--ghost btn--sm" type="button" data-action="logout">Sair</button>`
        :html`<a class="btn btn--ghost btn--sm" href="/entrar">Entrar</a><a class="btn btn--primary btn--sm" href="/cadastro">Cadastrar-se</a>`}
      <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="main-nav" aria-label="Abrir menu">${Icon('menu',24)}</button>
    </div>
  </div>
  <nav class="nav" id="main-nav" aria-label="Principal">
    <div class="container nav__inner">
      <ul>${config.nav.map(i=>html`<li><a href="${i.href}" ${active(i.href,path)?raw('aria-current="page"'):''}>${i.label}</a></li>`)}</ul>
      ${SearchBar({id:'header-search'})}
    </div>
  </nav>
</header>`;

export const PanelHeader=({user})=>html`
<header class="panel-header"><div class="container panel-header__inner">
  <span class="avatar" aria-hidden="true">${initials(user.name)}</span>
  <div class="panel-header__who"><p>Olá, ${user.name} <span aria-hidden="true">👋</span></p><span class="pill">${ROLES[user.role]}</span></div>
  <nav class="panel-header__actions" aria-label="Ações do painel">
    <a class="btn btn--ghost btn--sm" href="/">Ver site</a>
    <a class="btn btn--primary btn--sm" href="/painel/noticias/nova">${Icon('plus',16)} Novo</a>
    <button class="btn btn--ghost btn--sm" type="button" data-action="logout">Sair</button>
  </nav>
</div></header>`;

export function mountHeader(root){
  const btn=$(root,'.menu-toggle'),nav=$(root,'#main-nav');
  const set=open=>{nav.classList.toggle('is-open',open);btn.setAttribute('aria-expanded',String(open));btn.setAttribute('aria-label',open?'Fechar menu':'Abrir menu');};
  btn?.addEventListener('click',()=>set(!nav.classList.contains('is-open')));
  nav?.addEventListener('keydown',e=>{if(e.key==='Escape'){set(false);btn.focus();}});
  $(root,'[data-action=logout]')?.addEventListener('click',()=>{logout();navigate('/');});
}
