import {html,raw,$,$$} from '../utils/dom.js';
import {STATUS} from '../types.js';
import {Icon} from './icons.js';

export const Button=({label,href,type='button',variant='primary',attrs=''})=>href
  ?html`<a class="btn btn--${variant}" href="${href}">${label}</a>`
  :html`<button class="btn btn--${variant}" type="${type}" ${raw(attrs)}>${label}</button>`;

export const SectionTitle=({title,href,linkLabel='Ver todas',id,level=2})=>html`
<div class="section-title"><h${level} id="${id}">${title}</h${level}>${href&&html`<a class="section-title__link" href="${href}">${linkLabel}</a>`}</div>`;

export const Breadcrumb=items=>html`
<nav class="breadcrumb" aria-label="Você está em"><ol>${items.map((it,i)=>html`<li>${it.href&&i<items.length-1?html`<a href="${it.href}">${it.label}</a>`:html`<span aria-current="page">${it.label}</span>`}</li>`)}</ol></nav>`;

export const Pagination=({page,totalPages,href})=>totalPages<2?'':html`
<nav class="pagination" aria-label="Paginação"><ul>
  <li>${page>1?html`<a rel="prev" href="${href(page-1)}">Anterior</a>`:html`<span class="is-disabled">Anterior</span>`}</li>
  ${Array.from({length:totalPages},(_,i)=>i+1).map(p=>html`<li><a href="${href(p)}" ${p===page?raw('aria-current="page"'):''}>${p}</a></li>`)}
  <li>${page<totalPages?html`<a rel="next" href="${href(page+1)}">Próxima</a>`:html`<span class="is-disabled">Próxima</span>`}</li>
</ul></nav>`;

export const EmptyState=({title,text,action,level=2})=>html`
<div class="state"><h${level}>${title}</h${level}>${text&&html`<p>${text}</p>`}${action&&Button(action)}</div>`;
export const Loading=()=>html`<div class="state" role="status" aria-busy="true"><span class="spinner" aria-hidden="true"></span><p>Carregando…</p></div>`;
export const ErrorState=({message})=>html`
<div class="state state--error" role="alert"><h1>Algo deu errado</h1><p>${message}</p>
<div class="state__actions"><button class="btn btn--primary" type="button" data-action="reload">Tentar novamente</button><a class="btn btn--secondary" href="/">Ir para o início</a></div></div>`;

export const SearchBar=({value='',action='/busca',id='search',placeholder='Buscar no jornal'}={})=>html`
<form class="search" role="search" action="${action}" method="get" data-spa-get>
  <label class="sr-only" for="${id}">Buscar no site</label>
  <input id="${id}" type="search" name="q" value="${value}" placeholder="${placeholder}" autocomplete="off">
  <button class="search__btn" type="submit" aria-label="Buscar">${Icon('search')}</button>
</form>`;

export const StatusBadge=status=>html`<span class="status status--${status}">${STATUS[status]||status}</span>`;
export const StatCard=({value,label})=>html`<div class="stat"><strong>${value}</strong><span>${label}</span></div>`;

export const CtaBand=({title,text,stats,action,reverse=false})=>html`
<section class="cta ${reverse?'cta--reverse':''}" aria-label="${title}">
  <div class="cta__copy"><h2>${title}</h2><p>${text}</p>${Button(action)}</div>
  <ul class="cta__stats">${stats.map(s=>html`<li><strong>${s.value}</strong><span>${s.label}</span></li>`)}</ul>
</section>`;

/** Campo de formulário acessível (label, mensagem de erro, alternância de senha). */
export const Field=({id,label,type='text',value='',placeholder='',autocomplete,required=true,hint,as='input',options=[],rows=6,attrs=''})=>html`
<div class="field" data-field="${id}">
  <label for="${id}">${label}</label>
  <div class="field__control">
    ${as==='textarea'?html`<textarea id="${id}" name="${id}" rows="${rows}" aria-describedby="${id}-msg" ${required?raw('required'):''}>${value}</textarea>`
    :as==='select'?html`<select id="${id}" name="${id}" aria-describedby="${id}-msg" ${required?raw('required'):''}>${options.map(o=>html`<option value="${o.value}" ${o.value===value?raw('selected'):''}>${o.label}</option>`)}</select>`
    :html`<input id="${id}" name="${id}" type="${type}" value="${value}" placeholder="${placeholder}" autocomplete="${autocomplete||'off'}" aria-describedby="${id}-msg" ${required?raw('required'):''} ${raw(attrs)}>`}
    ${type==='password'&&html`<button class="field__toggle" type="button" aria-label="Mostrar senha" aria-pressed="false" data-toggle-password="${id}">${Icon('eye')}</button>`}
  </div>
  ${hint&&html`<p class="field__hint">${hint}</p>`}
  <p class="field__error" id="${id}-msg" role="alert"></p>
</div>`;

export function showFieldErrors(form,errors={}){
  $$(form,'[data-field]').forEach(f=>{
    const msg=errors[f.dataset.field]||'';
    $(f,'.field__error').textContent=msg;
    $$(f,'input,textarea,select').forEach(i=>msg?i.setAttribute('aria-invalid','true'):i.removeAttribute('aria-invalid'));
  });
}
/** Valida, bloqueia o botão durante o envio e mostra erros da API em [data-form-error]. */
export function bindForm(form,{validate=()=>({}),submit}){
  const status=$(form,'[data-form-error]');
  let attempted=false;
  const read=()=>Object.fromEntries(new FormData(form));
  // Só depois da 1ª tentativa de envio os erros passam a acompanhar a digitação (sem erro prematuro).
  form.addEventListener('input',()=>{if(attempted)showFieldErrors(form,validate(read()));});
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    if(form.getAttribute('aria-busy')==='true')return; // impede envio duplicado (Enter repetido)
    attempted=true;
    const data=read(),errors=validate(data,e.submitter);
    showFieldErrors(form,errors);status.textContent='';
    if(Object.keys(errors).length){$(form,'[aria-invalid=true]')?.focus();return;}
    const btns=$$(form,'button[type=submit]');
    btns.forEach(b=>b.disabled=true);e.submitter?.classList.add('is-loading');form.setAttribute('aria-busy','true');
    try{await submit(data,e.submitter);}
    catch(err){status.textContent=err.message||'Algo deu errado. Tente novamente.';}
    finally{btns.forEach(b=>b.disabled=false);e.submitter?.classList.remove('is-loading');form.removeAttribute('aria-busy');}
  });
}
export function mountPasswordToggles(root){
  $$(root,'[data-toggle-password]').forEach(b=>b.addEventListener('click',()=>{
    const input=document.getElementById(b.dataset.togglePassword),show=input.type==='password';
    input.type=show?'text':'password';
    b.setAttribute('aria-pressed',String(show));b.setAttribute('aria-label',show?'Ocultar senha':'Mostrar senha');
    b.innerHTML=Icon(show?'eye-off':'eye').s;
  }));
}
