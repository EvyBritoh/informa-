import {html,raw,$$} from '../utils/dom.js';
import {resolveImage} from '../assets/images.js';
import {EmptyState} from './ui.js';

export const CategoryBadge=c=>html`<a class="badge" href="/categoria/${c.slug}">${c.label}</a>`;

/** Card inteiro clicável via título (link esticado); badge fica acima do link. */
export const NewsCard=(n,{level=3}={})=>html`
<article class="card">
  <div class="card__media"><img src="${resolveImage(n.image)}" alt="" width="640" height="360" loading="lazy" decoding="async"></div>
  <div class="card__body">
    <div class="card__meta"><span>Por ${n.author.name}</span>${CategoryBadge(n.category)}</div>
    <p class="card__course">${n.course}</p>
    <h${level} class="card__title"><a class="card__link" href="/noticias/${n.slug}">${n.title}</a></h${level}>
  </div>
</article>`;

export const NewsGrid=(items,{level=3}={})=>items.length>0
  ?html`<div class="grid">${items.map(n=>NewsCard(n,{level}))}</div>`
  :EmptyState({title:'Nenhuma publicação encontrada',text:'Tente outro filtro ou volte mais tarde.',action:{label:'Ver últimas notícias',href:'/noticias',variant:'secondary'}});

export const FeaturedCarousel=items=>html`
<section class="hero" aria-roledescription="carrossel" aria-label="Destaques" data-carousel>
  ${items.map((n,i)=>html`
  <article class="hero__slide" data-slide ${i>0?raw('hidden'):''} aria-roledescription="slide" aria-label="${i+1} de ${items.length}">
    <img src="${resolveImage(n.image)}" alt="" width="1280" height="720" ${i>0?raw('loading="lazy"'):raw('fetchpriority="high"')}>
    <div class="hero__text">
      ${CategoryBadge(n.category)}
      <h2><a href="/noticias/${n.slug}">${n.title}</a></h2>
      <p>${n.excerpt}</p>
      <a class="btn btn--primary" href="/noticias/${n.slug}">Leia mais</a>
    </div>
  </article>`)}
  ${items.length>1&&html`<div class="hero__dots" role="group" aria-label="Escolher destaque">${items.map((n,i)=>html`<button class="dot" type="button" data-dot="${i}" aria-label="Destaque ${i+1}: ${n.title}" aria-current="${i===0?'true':'false'}"></button>`)}</div>`}
</section>`;

export function mountCarousel(root){
  $$(root,'[data-carousel]').forEach(c=>{
    const slides=$$(c,'[data-slide]'),dots=$$(c,'[data-dot]');
    dots.forEach(d=>d.addEventListener('click',()=>{
      const i=+d.dataset.dot;
      slides.forEach((s,k)=>{s.hidden=k!==i;});
      dots.forEach((x,k)=>x.setAttribute('aria-current',String(k===i)));
    }));
  });
}
