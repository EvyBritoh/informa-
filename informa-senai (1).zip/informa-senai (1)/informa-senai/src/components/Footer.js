import {html} from '../utils/dom.js';
import {config} from '../config.js';
export const Footer=({contributors})=>html`
<footer class="footer">
  <div class="container footer__grid">
    <div><h2 class="footer__title">In-Forma Senai</h2>
      <ul>${config.nav.map(i=>html`<li><a href="${i.href}">${i.label==='Últimas Notícias'?'Notícias':i.label}</a></li>`)}</ul></div>
    <div><h2 class="footer__title">Feitos por estudantes</h2>
      <ul class="footer__handles">${contributors.map(a=>html`<li><a href="/busca?q=${encodeURIComponent(a.name)}">${a.handle}</a></li>`)}</ul></div>
  </div>
  <p class="container footer__legal">${config.disclaimer}</p>
</footer>`;
