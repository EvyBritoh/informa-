import {$,$$} from './utils/dom.js';
import {setMeta} from './utils/seo.js';
import {layouts} from './layouts/index.js';
import {getCurrentUser} from './services/authService.js';
import {Loading,ErrorState} from './components/ui.js';

// Roteamento por hash (#/noticias): funciona em qualquer servidor estático (Live Server, GitHub Pages,
// python -m http.server) sem regra de fallback. Os templates continuam usando caminhos "/rota";
// o roteador os converte em "#/rota" depois de renderizar.
const routes=[];
/** route('/noticias/:slug', () => import('./pages/X.js'), {auth:true, props:{...}}) */
export const route=(pattern,load,opts={})=>routes.push({re:new RegExp('^'+pattern.replace(/:(\w+)/g,'(?<$1>[^/]+)')+'/?$'),load,...opts});
const currentUrl=()=>new URL(location.hash.slice(1)||'/','http://local');
function find(path){
  for(const r of routes){
    const m=r.re.exec(path);
    if(m)return {...r,params:Object.fromEntries(Object.entries(m.groups||{}).map(([k,v])=>[k,decodeURIComponent(v)]))};
  }
  return null;
}
let current=0;
const message=e=>e?.status===403?'Você não tem permissão para acessar esta página.':e?.message||'Não foi possível carregar o conteúdo.';
const notFound=async ctx=>(await import('./pages/NotFoundPage.js')).default(ctx);

function paint(page,ctx){
  const layout=layouts[page.layout||'site'],el=document.getElementById('app');
  el.innerHTML=layout.render(page.view,ctx).s;
  $$(el,'a[href^="/"]:not([href^="//"])').forEach(a=>a.setAttribute('href','#'+a.getAttribute('href')));
  setMeta(page);
  layout.mount?.(el,ctx);page.mount?.(el,ctx);
  window.scrollTo(0,0);$(el,'#conteudo')?.focus({preventScroll:true});
}
export function navigate(to,{replace=false}={}){
  const hash='#'+to;
  if(location.hash===hash)return render();
  if(replace){history.replaceState(null,'',hash);return render();}
  location.hash=to; // dispara hashchange -> render()
}
export async function render(){
  const id=++current,url=currentUrl(),hit=find(url.pathname),user=getCurrentUser();
  if(hit?.auth&&!user)return navigate('/entrar?next='+encodeURIComponent(url.pathname+url.search),{replace:true});
  const ctx={params:hit?.params||{},query:Object.fromEntries(url.searchParams),path:url.pathname,user,props:hit?.props||{}};
  const timer=setTimeout(()=>id===current&&paint({title:'Carregando',view:Loading()},ctx),150);
  let page;
  try{page=hit?await (await hit.load()).default(ctx):await notFound(ctx);}
  catch(err){
    if(err?.status===404)page=await notFound(ctx);
    else{if(!err?.status)console.error(err);page={title:'Erro',view:ErrorState({message:message(err)})};}
  }
  clearTimeout(timer);
  if(id===current)paint(page,ctx);
}
export function initRouter(){
  addEventListener('hashchange',render);
  document.addEventListener('click',e=>{
    if(e.target.closest('[data-action=reload]')){render();return;}
    if(e.target.closest('[data-skip]')){e.preventDefault();$(document,'#conteudo')?.focus();}
  });
  // Formulários GET (busca) navegam pelo roteador.
  document.addEventListener('submit',e=>{
    const f=e.target;
    if(f.matches('form[data-spa-get]')){e.preventDefault();navigate(f.getAttribute('action')+'?'+new URLSearchParams(new FormData(f)));}
  });
  return render();
}
