// Dados globais carregados uma vez na inicialização (usados pelo rodapé).
export const shell={contributors:[]};
