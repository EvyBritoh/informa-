// Persistência do mock (localStorage com fallback em memória). Não é usada quando config.useMock=false.
import {config} from '../config.js';
const mem={};
export const db={
  get(key,seed){
    if(!mem[key]){
      try{const r=localStorage.getItem(config.storagePrefix+key);mem[key]=r?JSON.parse(r):structuredClone(seed);}
      catch{mem[key]=structuredClone(seed);}
    }
    return mem[key];
  },
  set(key,value){mem[key]=value;try{localStorage.setItem(config.storagePrefix+key,JSON.stringify(value));}catch{/* quota/privacidade */}}
};
