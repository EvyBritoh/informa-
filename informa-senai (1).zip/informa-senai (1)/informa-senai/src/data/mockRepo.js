// "Banco de dados" falso com a mesma forma de resposta que a API real deve ter.
import {config} from '../config.js';
import {ApiError} from '../services/http.js';
import {session} from '../services/session.js';
import {db} from './store.js';
import {seedCategories,seedUsers,seedNews,seedProjects,seedEvents,seedStats} from './mock.js';
import {slugify} from '../utils/dom.js';

const K=n=>`${n}:v1`;
const norm=s=>String(s).normalize('NFD').replace(/\p{M}/gu,'').toLowerCase();
const today=()=>new Date().toISOString().slice(0,10);
const me=()=>session.get()?.user||null;
function requireUser(){const u=me();if(!u)throw new ApiError(401,'Faça login para continuar.');return u;}
const canEdit=(u,n)=>u.role==='admin'||n.authorId===u.id;
export const users=()=>db.get(K('users'),seedUsers);
const news=()=>db.get(K('news'),seedNews);
const events=()=>db.get(K('events'),seedEvents);
const author=id=>{const u=users().find(x=>x.id===id);return {id,name:u?.name||'Autor desconhecido',handle:u?.handle||''};};
const dto=n=>{const {authorId,...rest}=n;return {...rest,category:seedCategories.find(c=>c.slug===n.category)||{slug:n.category,label:n.category},author:author(authorId)};};
const sortKey=n=>n.publishedAt||n.submittedAt||'';
const pick=d=>({title:d.title.trim(),excerpt:d.excerpt.trim(),content:d.content,category:d.category,type:d.type,course:d.course||'',tags:d.tags||[],image:d.image||'placeholder:0'});
const page=(items,p,size)=>({items,total:items.length,page:p,pageSize:size,totalPages:Math.max(1,Math.ceil(items.length/size))});
const find=(all,id,label)=>{const x=all.find(i=>i.id===id);if(!x)throw new ApiError(404,`${label} não encontrado(a).`);return x;};

export const categoriesRepo={list:()=>seedCategories,bySlug:s=>{const c=seedCategories.find(x=>x.slug===s);if(!c)throw new ApiError(404,'Categoria não encontrada.');return c;}};

export const newsRepo={
  list({page:p=1,pageSize=config.pageSize,category,type,q,status='publicado',authorId,featured}={}){
    const st=status?[].concat(status):null;
    let items=news().filter(n=>(!st||st.includes(n.status))&&(!category||n.category===category)&&(!type||n.type===type)&&(!authorId||n.authorId===authorId)&&(!featured||n.featured));
    if(q?.trim()){const t=norm(q.trim());items=items.filter(n=>norm([n.title,n.excerpt,n.course,...n.tags,author(n.authorId).name].join(' ')).includes(t));}
    items=[...items].sort((a,b)=>sortKey(b).localeCompare(sortKey(a)));
    const pg=Math.max(1,+p||1);
    return {...page(items,pg,pageSize),items:items.slice((pg-1)*pageSize,pg*pageSize).map(dto)};
  },
  managed({status}={}){const u=requireUser();return newsRepo.list({status:status??null,authorId:u.role==='admin'?undefined:u.id,pageSize:100});},
  bySlug(slug){
    const n=news().find(x=>x.slug===slug),u=me();
    if(!n||(n.status!=='publicado'&&!(u&&canEdit(u,n))))throw new ApiError(404,'Notícia não encontrada.');
    return dto(n);
  },
  byId(id){const u=requireUser(),n=find(news(),id,'Notícia');if(!canEdit(u,n))throw new ApiError(403,'Sem permissão.');return dto(n);},
  related(n,limit){
    const pool=news().filter(x=>x.status==='publicado'&&x.id!==n.id).sort((a,b)=>(b.category===n.category.slug)-(a.category===n.category.slug)||sortKey(b).localeCompare(sortKey(a)));
    return pool.slice(0,limit).map(dto);
  },
  view(id){const all=news(),n=all.find(x=>x.id===id);if(n){n.views++;db.set(K('news'),all);}},
  create(d){
    const u=requireUser(),all=news(),status=d.status==='em_analise'&&u.role==='admin'?'publicado':d.status||'rascunho';
    let slug=slugify(d.title),i=2;while(all.some(x=>x.slug===slug))slug=`${slugify(d.title)}-${i++}`;
    const n={id:'n'+Date.now(),slug,...pick({...d,image:d.image||`placeholder:${all.length%6}`}),authorId:u.id,status,featured:false,views:0,feedback:null,submittedAt:today(),publishedAt:status==='publicado'?today():null};
    all.unshift(n);db.set(K('news'),all);return dto(n);
  },
  update(id,d){
    const u=requireUser(),all=news(),n=find(all,id,'Notícia');
    if(!canEdit(u,n))throw new ApiError(403,'Sem permissão.');
    if(u.role!=='admin'&&!['rascunho','revisao'].includes(n.status))throw new ApiError(409,'Este artigo já foi enviado e não pode mais ser editado.');
    const status=d.status==='em_analise'&&u.role==='admin'?'publicado':d.status||n.status;
    Object.assign(n,pick({...n,...d}),{status,feedback:status==='em_analise'?null:n.feedback,
      submittedAt:status==='em_analise'?today():n.submittedAt,publishedAt:status==='publicado'?n.publishedAt||today():n.publishedAt});
    db.set(K('news'),all);return dto(n);
  },
  review(id,{decision,feedback}){
    const u=requireUser();if(u.role!=='admin')throw new ApiError(403,'Apenas administradores podem revisar.');
    const all=news(),n=find(all,id,'Notícia');
    if(decision==='approve')Object.assign(n,{status:'publicado',publishedAt:today(),feedback:null});
    else Object.assign(n,{status:'revisao',feedback:{text:feedback,reviewer:u.name,date:today()}});
    db.set(K('news'),all);return dto(n);
  },
  remove(id){
    const u=requireUser(),all=news(),n=find(all,id,'Notícia');
    if(!canEdit(u,n)||(u.role!=='admin'&&n.status==='publicado'))throw new ApiError(403,'Sem permissão para excluir.');
    db.set(K('news'),all.filter(x=>x.id!==id));return null;
  },
  stats(){
    const u=requireUser(),mine=news().filter(n=>u.role==='admin'||n.authorId===u.id),pub=mine.filter(n=>n.status==='publicado');
    return {published:pub.length,pending:mine.filter(n=>n.status==='em_analise').length,reads:pub.reduce((s,n)=>s+n.views,0),
      score:u.role==='admin'?{label:'Média de interesse',value:`${seedStats.interest}/100`}:{label:'Nota média',value:`${seedStats.rating.toFixed(1)}/5.0`}};
  },
  site:()=>seedStats
};

export const eventsRepo={
  list:()=>[...events()].sort((a,b)=>a.date.localeCompare(b.date)),
  upcoming:limit=>eventsRepo.list().filter(e=>e.date>=today()).slice(0,limit),
  create({title,date}){requireUser();const all=events(),e={id:'e'+Date.now(),title:title.trim(),date};all.push(e);db.set(K('events'),all);return e;},
  update(id,{title,date}){requireUser();const all=events(),e=find(all,id,'Evento');Object.assign(e,{title:title.trim(),date});db.set(K('events'),all);return e;},
  remove(id){requireUser();db.set(K('events'),events().filter(e=>e.id!==id));return null;}
};

export const projectsRepo={
  list({limit}={}){return seedProjects.slice(0,limit||seedProjects.length).map(p=>({...p,author:author(p.authorId)}));},
  bySlug(slug){const p=seedProjects.find(x=>x.slug===slug);if(!p)throw new ApiError(404,'Projeto não encontrado.');return {...p,author:author(p.authorId)};}
};
