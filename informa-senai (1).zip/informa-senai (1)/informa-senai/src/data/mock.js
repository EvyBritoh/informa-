// Dados de desenvolvimento. Nenhuma página importa este arquivo: tudo passa por src/services.
import {slugify} from '../utils/dom.js';

export const seedCategories=[
  {slug:'eletronica',label:'Eletrônica'},{slug:'automacao',label:'Automação'},{slug:'robotica',label:'Robótica'},
  {slug:'mecanica',label:'Mecânica'},{slug:'soldagem',label:'Soldagem'},{slug:'ti',label:'Tecnologia da Informação'}
];
export const seedUsers=[
  {id:'u1',name:'Ricardo Almeida',role:'admin',handle:'@ricardo.almeida'},
  {id:'u2',name:'Evellyn Vitoria',role:'escritor',handle:'@evellyn.vitoria'},
  {id:'u3',name:'Lucas Ferreira',role:'escritor',handle:'@lucas.ferreira'},
  {id:'u4',name:'Marina Costa',role:'escritor',handle:'@marina.costa'},
  {id:'u5',name:'Pedro Santos',role:'escritor',handle:'@pedro.santos'}
];
const DEFAULT_BODY='Os estudantes destacam o impacto prático da iniciativa nas aulas e nos laboratórios, e o projeto segue aberto a novas turmas do SENAI.';
const mk=(id,title,category,type,authorId,course,date,views,tags,excerpt,extra={})=>{
  const {body=DEFAULT_BODY,...rest}=extra;
  return {id,title,slug:slugify(title),excerpt,content:`<p>${excerpt}</p><p>${body}</p>`,image:`placeholder:${+id.slice(1)%6}`,
    category,authorId,course,type,status:'publicado',publishedAt:date,submittedAt:date,tags,featured:false,views,feedback:null,...rest};
};
export const seedNews=[
  mk('n1','Novo laboratório de circuitos impressos é inaugurado','eletronica','noticia','u2','Curso de Automação Industrial','2026-10-01',320,['laboratório','eletrônica'],'O espaço reúne fresadora CNC, estação de solda e bancadas de teste para que turmas produzam placas do projeto à montagem.',{featured:true}),
  mk('n2','Robótica Avançada: O Futuro da Automação','robotica','artigo','u1','Curso de Automação Industrial','2026-05-12',1240,['robótica','automação'],'Um panorama de braços colaborativos, visão computacional e aprendizado de máquina aplicados ao chão de fábrica.',{featured:true}),
  mk('n3','Manutenção Preditiva com Sensores IoT na Oficina','automacao','artigo','u1','Curso de Automação Industrial',null,0,['iot','manutenção'],'Como sensores de vibração e temperatura antecipam falhas em máquinas da oficina antes da parada.',{status:'em_analise',submittedAt:'2026-09-08',publishedAt:null}),
  mk('n4','Alunos de Mecatrônica vencem torneio regional de robôs','robotica','noticia','u3','Mecatrônica','2026-09-24',540,['robótica','competição'],'A equipe do SENAI conquistou o primeiro lugar na prova de seguidor de linha e se classificou para a etapa estadual.',{featured:true}),
  mk('n5','Soldagem TIG em alumínio: guia para iniciantes','soldagem','artigo','u4','Soldagem','2026-09-18',410,['soldagem','alumínio'],'Preparação da junta, gás de proteção e controle de corrente: os cuidados que evitam porosidade no cordão.'),
  mk('n6','Semana de TI reúne mais de 300 participantes','ti','noticia','u2','Desenvolvimento de Sistemas','2026-09-10',275,['evento','programação'],'Palestras, maratona de código e oficinas de nuvem movimentaram o campus durante cinco dias.',{featured:true}),
  mk('n7','Como o ESP32 está mudando projetos de IoT na escola','eletronica','artigo','u3','Eletrônica','2026-08-29',690,['esp32','iot'],'Wi-Fi, Bluetooth e baixo custo fazem do microcontrolador a base de protótipos conectados dos alunos.'),
  mk('n8','Visita técnica à indústria 4.0 marca o semestre','automacao','noticia','u4','Automação Industrial','2026-08-15',230,['visita técnica','indústria 4.0'],'Turmas acompanharam linhas conectadas e conversaram com engenheiros sobre carreira.'),
  mk('n9','Impressão 3D acelera a prototipagem de peças','mecanica','artigo','u2','Mecânica','2026-08-02',380,['impressão 3d','prototipagem'],'Da modelagem ao ajuste fino, a manufatura aditiva reduz o tempo entre ideia e peça testada.'),
  mk('n10','Segurança em laboratórios elétricos','eletronica','artigo','u2','Eletricidade','2026-09-14',0,['segurança','nr-10'],'Boas práticas de bloqueio, aterramento e uso de EPI nas aulas práticas.',{status:'revisao',publishedAt:null,
    feedback:{reviewer:'Prof. Marcos Tadeu',date:'2026-09-16',text:'Ajustar a seção de metodologia e incluir referências normativas ABNT sobre sensores IoT industriais.'}}),
  mk('n11','Energia solar no campus: primeiros resultados','ti','artigo','u3','Eletrotécnica','2026-09-20',0,['energia','sustentabilidade'],'Dados iniciais de geração e economia com os painéis instalados no bloco B.',{status:'rascunho',publishedAt:null})
];
export const seedProjects=[
  {id:'p1',title:'Painel de Monitoramento de Impressoras 3D',kind:'Impressão',authorId:'u2',course:'Curso de Automação Industrial',summary:'Dashboard web que acompanha fila, temperatura e tempo restante das impressoras 3D do laboratório.',url:null},
  {id:'p2',title:'Catálogo Digital de Peças Usinadas',kind:'Mecânica',authorId:'u4',course:'Mecânica',summary:'Catálogo pesquisável com desenhos, materiais e tolerâncias das peças produzidas nas aulas de usinagem.',url:null},
  {id:'p3',title:'Dashboard IoT de Consumo de Energia',kind:'IoT',authorId:'u3',course:'Eletrônica',summary:'Visualização em tempo real do consumo elétrico dos laboratórios usando sensores com ESP32.',url:null},
  {id:'p4',title:'Agenda de Laboratórios',kind:'Web',authorId:'u5',course:'Desenvolvimento de Sistemas',summary:'Sistema de reserva de laboratórios e equipamentos com confirmação por e-mail.',url:null},
  {id:'p5',title:'Simulador de Circuitos Lógicos',kind:'Eletrônica',authorId:'u3',course:'Eletrônica',summary:'Ferramenta no navegador para montar e testar portas lógicas com tabela-verdade automática.',url:null},
  {id:'p6',title:'Calculadora de Parâmetros de Soldagem',kind:'Soldagem',authorId:'u4',course:'Soldagem',summary:'Sugere corrente, gás e velocidade conforme material e espessura informados.',url:null}
].map((p,i)=>({...p,slug:slugify(p.title),image:`placeholder:${i+1}`}));
export const seedEvents=[
  {id:'e1',title:'Workshop: Soldagem TIG em Alumínio',date:'2026-10-15'},
  {id:'e2',title:'Palestra: O Mercado de IoT no Brasil',date:'2026-10-18'},
  {id:'e3',title:'Feira de Talentos e Contratação',date:'2026-10-20'}
];
// Números institucionais e métricas que o backend vai calcular (nota/interesse ainda não existem no modelo).
export const seedStats={articlesPublished:20,courses:12,users:1000,interest:70,rating:4.9};
