import {html} from '../utils/dom.js';
import {getFeaturedNews,getNews,getSiteStats} from '../services/newsService.js';
import {getUpcomingEvents} from '../services/eventService.js';
import {getProjects} from '../services/projectService.js';
import {FeaturedCarousel,NewsGrid,mountCarousel} from '../components/news.js';
import {AgendaCard,mountAgenda} from '../components/AgendaCard.js';
import {ProjectCard} from '../components/ProjectCard.js';
import {SectionTitle,CtaBand} from '../components/ui.js';

export default async function HomePage({user}){
  const [featured,latest,events,projects,stats]=await Promise.all([
    getFeaturedNews(3),getNews({pageSize:3}),getUpcomingEvents(3),getProjects({limit:3}),getSiteStats()]);
  const slides=featured.length>0?featured:latest.items;
  return {
    description:'Notícias, artigos e projetos web dos estudantes do SENAI em Santa Bárbara d\'Oeste. Edição mensal do IN-FORMA SENAI.',
    view:html`<div class="container">
      <h1 class="sr-only">IN-FORMA SENAI — jornal dos estudantes</h1>
      <div class="home-top">${slides.length>0&&FeaturedCarousel(slides)}${AgendaCard({events})}</div>
      <section class="block" aria-labelledby="latest-title">
        ${SectionTitle({title:'Últimas Notícias',href:'/noticias',id:'latest-title'})}
        ${NewsGrid(latest.items)}
      </section>
      ${CtaBand({title:'Quer escrever para o In-Forma SENAI?',text:'Envie seu artigo acadêmico ou projeto e ganhe visibilidade em toda a rede SENAI.',
        stats:[{value:'+'+stats.articlesPublished,label:'Artigos publicados'},{value:stats.courses,label:'Cursos envolvidos'}],
        action:{label:'Enviar artigo',href:'/painel/noticias/nova'}})}
      <section class="block" aria-labelledby="projects-title">
        ${SectionTitle({title:'Projetos Web de Alunos',href:'/projetos',id:'projects-title'})}
        <div class="grid">${projects.map(p=>ProjectCard(p))}</div>
      </section>
      ${CtaBand({reverse:true,title:'Quer ver artigos sobre seu curso?',
        text:user?'Explore os artigos publicados pelos estudantes da sua área.':'Crie sua conta e acompanhe as publicações dos estudantes da sua área.',
        stats:[{value:'+ de '+stats.users.toLocaleString('pt-BR'),label:'Usuários cadastrados'},{value:stats.courses,label:'Cursos envolvidos'}],
        action:user?{label:'Ver artigos',href:'/artigos'}:{label:'Inscrever-se',href:'/cadastro'}})}
    </div>`,
    mount(root){mountCarousel(root);mountAgenda(root,events);}
  };
}
