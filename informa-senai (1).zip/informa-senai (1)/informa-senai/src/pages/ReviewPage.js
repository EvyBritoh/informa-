import {html,raw,$} from '../utils/dom.js';
import {sanitizeHtml} from '../utils/sanitize.js';
import {resolveImage} from '../assets/images.js';
import {ApiError} from '../services/http.js';
import {getNewsById,reviewNews,deleteNews} from '../services/newsService.js';
import {navigate} from '../router.js';
import {openDialog,confirmDialog} from '../components/dialog.js';
import {Icon} from '../components/icons.js';
import {Field,StatusBadge} from '../components/ui.js';

/** Equivale ao "Modal - ler notícia" do wireframe: o administrador aprova, devolve para revisão ou deleta. */
export default async function ReviewPage({params,user}){
  if(user.role!=='admin')throw new ApiError(403,'Apenas administradores podem revisar artigos.');
  const n=await getNewsById(params.id);
  return {
    layout:'panel',title:`Revisar: ${n.title}`,description:'Revisão editorial de artigo.',
    view:html`<div class="container editor">
      <a class="back" href="/painel">${Icon('arrow-left',18)} Voltar</a>
      <h1>Revisar notícia</h1>
      <div class="review">
        <div class="review__main">
          <h2 class="review__title">${n.title}</h2>
          <p class="article__meta"><span>Por <strong>${n.author.name}</strong></span><span>${n.category.label}</span>${StatusBadge(n.status)}</p>
          <div class="prose review__body">${raw(sanitizeHtml(n.content))}</div>
        </div>
        <figure class="review__side"><img src="${resolveImage(n.image)}" alt="Imagem principal de ${n.title}" width="640" height="360"></figure>
      </div>
      <p class="form-error" role="alert" data-form-error></p>
      <div class="editor__actions">
        <button class="btn btn--primary" type="button" data-decision="approve">Aprovar</button>
        <button class="btn btn--secondary" type="button" data-decision="revision">Revisão</button>
        <a class="btn btn--ghost" href="/noticias/${n.slug}">Ver como leitor</a>
        <button class="btn btn--danger" type="button" data-action="delete">Deletar</button>
      </div>
    </div>`,
    mount(root){
      const error=$(root,'[data-form-error]');
      const run=async fn=>{try{await fn();navigate('/painel');}catch(e){error.textContent=e.message;}};
      $(root,'[data-decision=approve]').addEventListener('click',()=>run(()=>reviewNews(n.id,{decision:'approve'})));
      $(root,'[data-decision=revision]').addEventListener('click',async()=>{
        const r=await openDialog({title:'Devolver para revisão',body:Field({id:'feedback',label:'O que precisa ser ajustado?',as:'textarea',rows:5}),
          actions:[{label:'Cancelar',value:'cancel',skipValidation:true},{label:'Enviar feedback',value:'send',variant:'primary'}]});
        if(r.value==='send')run(()=>reviewNews(n.id,{decision:'revision',feedback:r.data.feedback.trim()}));
      });
      $(root,'[data-action=delete]').addEventListener('click',async()=>{
        if(await confirmDialog('Deletar notícia',`Excluir “${n.title}” definitivamente?`,'Deletar'))run(()=>deleteNews(n.id));
      });
    }
  };
}
