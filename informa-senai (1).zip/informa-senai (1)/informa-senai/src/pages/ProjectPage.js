import {html} from '../utils/dom.js';
import {resolveImage} from '../assets/images.js';
import {getProjectBySlug} from '../services/projectService.js';
import {Breadcrumb,Button} from '../components/ui.js';
export default async function ProjectPage({params}){
  const p=await getProjectBySlug(params.slug);
  return {title:p.title,description:p.summary,
    view:html`<article class="container article">
      ${Breadcrumb([{label:'Início',href:'/'},{label:'Projetos',href:'/projetos'},{label:p.title}])}
      <header class="article__head"><span class="badge badge--static">${p.kind}</span><h1>${p.title}</h1>
        <p class="article__meta"><span>Por <strong>${p.author.name}</strong></span><span>${p.course}</span></p></header>
      <figure class="article__figure"><img src="${resolveImage(p.image)}" alt="Imagem ilustrativa do projeto ${p.title}" width="1280" height="720"></figure>
      <div class="prose"><p>${p.summary}</p></div>
      <div class="article__actions">${p.url&&html`<a class="btn btn--primary" href="${p.url}" target="_blank" rel="noopener noreferrer">Abrir projeto online</a>`}${Button({label:'Ver todos os projetos',href:'/projetos',variant:'secondary'})}</div>
    </article>`};
}
