import {html,$,$$,formatDate} from '../utils/dom.js';
import {getDashboardStats,getManagedNews} from '../services/newsService.js';
import {getEvents,createEvent,updateEvent,deleteEvent} from '../services/eventService.js';
import {render} from '../router.js';
import {openDialog,confirmDialog} from '../components/dialog.js';
import {StatCard,StatusBadge,EmptyState,Field,bindForm} from '../components/ui.js';

const TABS=[
  {id:'todos',label:'Todos',statuses:null},
  {id:'pendentes',label:'Pendentes',statuses:['em_analise']},
  {id:'publicados',label:'Publicados',statuses:['publicado']},
  {id:'rascunhos',label:'Rascunhos',statuses:['rascunho','revisao']}
];
const btn=(attr,id,label)=>html`<button class="btn btn--ghost btn--sm" type="button" ${attr}="${id}">${label}</button>`;
function rowActions(n,user){
  const link=(href,label)=>html`<a class="btn btn--ghost btn--sm" href="${href}">${label}</a>`;
  if(n.status==='publicado')return html`${link(`/noticias/${n.slug}`,'Ver no site')}${btn('data-stats',n.id,'Estatísticas')}`;
  if(n.status==='em_analise')return user.role==='admin'?link(`/painel/noticias/${n.id}/revisar`,'Revisar'):link(`/noticias/${n.slug}`,'Visualizar');
  return html`${link(`/painel/noticias/${n.id}/editar`,'Editar')}${n.status==='revisao'&&btn('data-feedback',n.id,'Feedback')}`;
}

export default async function DashboardPage({user,query}){
  const tab=TABS.find(t=>t.id===query.status)||TABS[0];
  const [stats,managed,events]=await Promise.all([getDashboardStats(),getManagedNews(),getEvents()]);
  const all=managed.items,items=tab.statuses?all.filter(n=>tab.statuses.includes(n.status)):all;
  const byId=Object.fromEntries(all.map(n=>[n.id,n])),evById=Object.fromEntries(events.map(e=>[e.id,e]));
  const feedback=all.find(n=>n.status==='revisao'&&n.feedback);
  return {
    layout:'panel',title:'Painel',description:'Painel de gerenciamento de artigos e agenda.',
    view:html`<div class="container">
      <h1 class="sr-only">Painel de ${user.role==='admin'?'administração':'escritor'}</h1>
      <section class="stats" aria-label="Resumo">
        ${StatCard({value:stats.published,label:'Publicados'})}${StatCard({value:stats.pending,label:'Em análise'})}
        ${StatCard({value:stats.reads.toLocaleString('pt-BR'),label:'Leituras'})}${StatCard({value:stats.score.value,label:stats.score.label})}
      </section>
      <section class="block" aria-labelledby="articles-title">
        <h2 id="articles-title" class="panel__title">${user.role==='admin'?'Artigos':'Meus artigos'}</h2>
        <nav class="tabs" aria-label="Filtrar por status"><ul>${TABS.map(t=>html`<li><a href="/painel${t.id==='todos'?'':`?status=${t.id}`}" ${t.id===tab.id?html`aria-current="page"`:''}>${t.label}</a></li>`)}</ul></nav>
        ${items.length>0?html`<div class="table-wrap"><table class="table">
          <caption class="sr-only">Artigos filtrados por ${tab.label}</caption>
          <thead><tr><th scope="col">Título do artigo</th><th scope="col">Data envio</th><th scope="col">Categoria</th><th scope="col">Status</th><th scope="col">Leituras</th><th scope="col">Ações</th></tr></thead>
          <tbody>${items.map(n=>html`<tr>
            <th scope="row" data-label="Título">${n.title}</th>
            <td data-label="Data envio">${formatDate(n.submittedAt)}</td><td data-label="Categoria">${n.category.label}</td>
            <td data-label="Status">${StatusBadge(n.status)}</td>
            <td data-label="Leituras">${n.status==='publicado'?n.views.toLocaleString('pt-BR'):'–'}</td>
            <td data-label="Ações" class="table__actions">${rowActions(n,user)}</td></tr>`)}</tbody></table></div>`
        :EmptyState({title:'Nenhum artigo por aqui',text:'Quando você enviar ou salvar artigos, eles aparecem nesta lista.',action:{label:'Escrever artigo',href:'/painel/noticias/nova'}})}
      </section>
      ${feedback&&html`<section class="feedback" aria-labelledby="feedback-title"><h2 id="feedback-title">Feedback do conselho editorial</h2>
        <p><strong>${feedback.title}</strong></p><p>Revisor: ${feedback.feedback.reviewer} — “${feedback.feedback.text}”</p></section>`}
      <section class="block agenda-admin" aria-labelledby="agenda-admin-title">
        <h2 id="agenda-admin-title" class="panel__title">Gerencie sua agenda</h2>
        <form class="agenda-admin__form" novalidate id="event-form">
          ${Field({id:'title',label:'Título do evento',attrs:'maxlength="90"'})}${Field({id:'date',label:'Data',type:'date'})}
          <button class="btn btn--primary" type="submit">Adicionar</button>
          <p class="form-error" role="alert" data-form-error></p>
        </form>
        ${events.length>0?html`<ul class="agenda-admin__list">${events.map(e=>html`<li><span>${e.title}</span><time datetime="${e.date}">${formatDate(e.date)}</time>${btn('data-edit-event',e.id,'Editar')}</li>`)}</ul>`
          :html`<p class="agenda__empty">Nenhum evento ainda. Adicione o primeiro acima.</p>`}
      </section>
    </div>`,
    mount(root){
      $$(root,'[data-stats]').forEach(b=>b.addEventListener('click',()=>{const n=byId[b.dataset.stats];
        openDialog({title:'Estatísticas',body:html`<p><strong>${n.title}</strong></p><dl class="dl"><dt>Leituras</dt><dd>${n.views.toLocaleString('pt-BR')}</dd><dt>Publicado em</dt><dd>${formatDate(n.publishedAt)}</dd></dl>`,actions:[{label:'Fechar',value:'ok',variant:'primary',skipValidation:true}]});}));
      $$(root,'[data-feedback]').forEach(b=>b.addEventListener('click',()=>{const n=byId[b.dataset.feedback];
        openDialog({title:'Feedback do conselho editorial',body:html`<p><strong>${n.title}</strong></p><p>Revisor: ${n.feedback?.reviewer}</p><p>${n.feedback?.text}</p>`,actions:[{label:'Fechar',value:'ok',variant:'primary',skipValidation:true}]});}));
      bindForm($(root,'#event-form'),{
        validate:d=>({...(d.title.trim().length<3&&{title:'Informe o título do evento.'}),...(!d.date&&{date:'Escolha a data.'})}),
        submit:async d=>{await createEvent(d);await render();}});
      $$(root,'[data-edit-event]').forEach(b=>b.addEventListener('click',async()=>{
        const e=evById[b.dataset.editEvent];
        const r=await openDialog({title:'Editar evento',body:html`${Field({id:'title',label:'Título do evento',value:e.title})}${Field({id:'date',label:'Data',type:'date',value:e.date})}`,
          actions:[{label:'Excluir',value:'delete',variant:'danger',skipValidation:true},{label:'Cancelar',value:'cancel',skipValidation:true},{label:'Salvar',value:'save',variant:'primary'}]});
        if(r.value==='save'){await updateEvent(e.id,r.data);await render();}
        if(r.value==='delete'&&await confirmDialog('Excluir evento',`Excluir “${e.title}”?`,'Excluir')){await deleteEvent(e.id);await render();}
      }));
    }
  };
}
