import {html,$} from '../utils/dom.js';
import {login,isValidEmail} from '../services/authService.js';
import {navigate} from '../router.js';
import {AuthShell,AuthSwitch} from '../components/AuthShell.js';
import {Field,Button,bindForm,mountPasswordToggles} from '../components/ui.js';

export default async function LoginPage({query,user}){
  if(user)queueMicrotask(()=>navigate('/painel',{replace:true}));
  return {layout:'auth',title:'Entrar',description:'Acesse sua conta para publicar artigos e acompanhar métricas no IN-FORMA SENAI.',
    view:AuthShell({heading:'Bem vindo!',
      children:html`<form class="form" novalidate>
        ${Field({id:'email',label:'E-mail institucional',type:'email',placeholder:'Digite seu e-mail institucional',autocomplete:'username'})}
        ${Field({id:'password',label:'Senha',type:'password',placeholder:'Digite sua senha',autocomplete:'current-password'})}
        <a class="form__aside" href="/recuperar-senha">Esqueceu a senha?</a>
        <p class="form-error" role="alert" data-form-error></p>
        ${Button({label:'Entrar',type:'submit'})}
      </form>
      ${AuthSwitch({text:'Não tem uma conta?',label:'Cadastrar-se',href:'/cadastro'})}`}),
    mount(root){
      mountPasswordToggles(root);
      bindForm($(root,'form'),{
        validate:d=>({
          ...(!d.email.trim()?{email:'Informe seu e-mail institucional.'}:!isValidEmail(d.email)?{email:'Digite um e-mail válido.'}:{}),
          ...(!d.password&&{password:'Informe sua senha.'})}),
        submit:async d=>{await login(d.email,d.password);const next=query.next;navigate(next&&next.startsWith('/')&&!next.startsWith('//')?next:'/painel');}
      });
    }};
}
