import {html,$} from '../utils/dom.js';
import {register,getCurrentUser,isInstitutionalEmail,isValidEmail} from '../services/authService.js';
import {navigate} from '../router.js';
import {AuthShell,AuthSwitch} from '../components/AuthShell.js';
import {Field,Button,bindForm,mountPasswordToggles} from '../components/ui.js';

export default async function RegisterPage({user}){
  if(user)queueMicrotask(()=>navigate('/painel',{replace:true}));
  return {layout:'auth',title:'Criar conta',description:'Crie sua conta institucional para publicar no IN-FORMA SENAI.',
    view:AuthShell({heading:'Bem vindo!',
      children:html`<form class="form" novalidate>
        ${Field({id:'email',label:'E-mail institucional',type:'email',placeholder:'Digite seu e-mail institucional',autocomplete:'username',hint:'Use seu e-mail @senai.br ou @aluno.senai.br.'})}
        ${Field({id:'password',label:'Senha',type:'password',placeholder:'Digite sua senha',autocomplete:'new-password',hint:'Mínimo de 8 caracteres.'})}
        ${Field({id:'confirm',label:'Repetir senha',type:'password',placeholder:'Digite novamente sua senha',autocomplete:'new-password'})}
        <p class="form-error" role="alert" data-form-error></p><p class="form-success" role="status"></p>
        ${Button({label:'Cadastrar-se',type:'submit'})}
      </form>
      ${AuthSwitch({text:'Já tem uma conta?',label:'Acessar conta',href:'/entrar'})}`}),
    mount(root){
      mountPasswordToggles(root);
      const form=$(root,'form');
      bindForm(form,{
        validate:d=>({
          ...(!d.email.trim()?{email:'Informe seu e-mail institucional.'}:!isValidEmail(d.email)?{email:'Digite um e-mail válido.'}
            :!isInstitutionalEmail(d.email)?{email:'Use um e-mail @senai.br ou @aluno.senai.br.'}:{}),
          ...(d.password.length<8&&{password:'A senha precisa ter ao menos 8 caracteres.'}),
          ...(!d.confirm?{confirm:'Repita a senha.'}:d.confirm!==d.password?{confirm:'As senhas não coincidem.'}:{})}),
        submit:async d=>{
          await register(d.email,d.password);
          if(getCurrentUser())navigate('/painel');
          else $(form,'.form-success').textContent='Cadastro realizado! Agora você já pode acessar sua conta.';
        }
      });
    }};
}
