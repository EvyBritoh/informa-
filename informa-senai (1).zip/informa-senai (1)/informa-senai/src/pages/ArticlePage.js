import {html,raw,formatDate,readingMinutes} from '../utils/dom.js';
import {sanitizeHtml} from '../utils/sanitize.js';
import {resolveImage} from '../assets/images.js';
import {getNewsBySlug,getRelatedNews,registerView} from '../services/newsService.js';
import {Breadcrumb,SectionTitle} from '../components/ui.js';
import {CategoryBadge,NewsGrid} from '../components/news.js';

export default async function ArticlePage({params}){
  const n=await getNewsBySlug(params.slug);
  const published=n.status==='publicado';
  const related=published?await getRelatedNews(n,3):[];
  if(published)registerView(n.id);
  const date=n.publishedAt||n.submittedAt;
  const listLabel=n.type==='artigo'?{label:'Artigos',href:'/artigos'}:{label:'Últimas Notícias',href:'/noticias'};
  return {
    title:n.title,description:n.excerpt,image:n.image,type:'article',
    // Pronto para NewsArticle; o backend pode preencher url/imagem absolutas depois.
    jsonLd:{'@context':'https://schema.org','@type':'NewsArticle',headline:n.title,description:n.excerpt,
      datePublished:n.publishedAt||undefined,author:[{'@type':'Person',name:n.author.name}],articleSection:n.category.label,keywords:n.tags.join(', '),
      ...(n.image.startsWith('http')||n.image.startsWith('/')?{image:[n.image]}:{})},
    view:html`<article class="container article">
      ${Breadcrumb([{label:'Início',href:'/'},{...listLabel},{label:n.category.label,href:`/categoria/${n.category.slug}`},{label:n.title}])}
      ${!published&&html`<p class="notice" role="status">Pré-visualização: este conteúdo ainda não foi publicado.</p>`}
      <header class="article__head">
        ${CategoryBadge(n.category)}
        <h1>${n.title}</h1>
        <p class="article__excerpt">${n.excerpt}</p>
        <p class="article__meta"><span>Por <strong>${n.author.name}</strong></span><time datetime="${date}">${formatDate(date)}</time><span>${readingMinutes(n.content)} min de leitura</span><span>${n.course}</span></p>
      </header>
      <figure class="article__figure"><img src="${resolveImage(n.image)}" alt="${n.imageAlt||n.title}" width="1280" height="720" fetchpriority="high"></figure>
      <div class="prose">${raw(sanitizeHtml(n.content))}</div>
      ${n.tags.length>0&&html`<ul class="tags" aria-label="Tags">${n.tags.map(t=>html`<li><a href="/busca?q=${encodeURIComponent(t)}">#${t}</a></li>`)}</ul>`}
    </article>
    ${related.length>0&&html`<section class="container block" aria-labelledby="related-title">${SectionTitle({title:'Notícias relacionadas',href:'/noticias',id:'related-title'})}${NewsGrid(related)}</section>`}`
  };
}
