import {html} from '../utils/dom.js';
import {buildUrl} from '../utils/dom.js';
import {ApiError} from '../services/http.js';
import {getNews} from '../services/newsService.js';
import {getCategories} from '../services/categoryService.js';
import {NewsGrid} from '../components/news.js';
import {Breadcrumb,Pagination,SearchBar} from '../components/ui.js';

/** Serve /noticias, /artigos, /categoria/:slug e /busca (configuração vem de ctx.props). */
export default async function ListingPage({props,params,query}){
  const page=Math.max(1,parseInt(query.page,10)||1),q=(query.q||'').trim();
  const cats=await getCategories();
  const isCategoryRoute=Boolean(params.slug),slug=params.slug||query.categoria||'';
  const category=cats.find(c=>c.slug===slug);
  if(isCategoryRoute&&!category)throw new ApiError(404,'Categoria não encontrada.');
  const isSearch=props.mode==='search';
  const res=await getNews({page,type:props.type,category:slug||undefined,q:q||undefined});
  const base=isCategoryRoute?`/categoria/${slug}`:props.base;
  const heading=isSearch?(q?`Resultados para “${q}”`:'Buscar'):isCategoryRoute?category.label:props.heading;
  const chipHref=c=>isCategoryRoute?`/categoria/${c.slug}`:buildUrl(base,{q:q||undefined,categoria:c.slug});
  const pageHref=p=>buildUrl(base,{q:q||undefined,categoria:isCategoryRoute?undefined:slug||undefined,page:p>1?p:undefined});
  return {
    title:heading+(page>1?` — página ${page}`:''),
    description:props.description||`Publicações do IN-FORMA SENAI${category?` na categoria ${category.label}`:''}.`,
    view:html`<div class="container listing">
      ${Breadcrumb([{label:'Início',href:'/'},{label:heading}])}
      <h1>${heading}</h1>
      ${isSearch&&html`<div class="listing__search">${SearchBar({value:q,id:'page-search',action:'/busca'})}</div>`}
      <nav class="chips" aria-label="Filtrar por categoria"><ul>
        <li><a href="${isCategoryRoute?'/noticias':buildUrl(base,{q:q||undefined})}" ${!slug?html`aria-current="true"`:''}>Todas</a></li>
        ${cats.map(c=>html`<li><a href="${chipHref(c)}" ${c.slug===slug?html`aria-current="true"`:''}>${c.label}</a></li>`)}
      </ul></nav>
      <p class="listing__count" role="status">${res.total} ${res.total===1?'resultado':'resultados'}</p>
      ${isSearch&&!q?html`<div class="state"><p>Digite um termo para buscar notícias, artigos, tags ou autores.</p></div>`:NewsGrid(res.items)}
      ${Pagination({page:res.page,totalPages:res.totalPages,href:pageHref})}
    </div>`
  };
}
