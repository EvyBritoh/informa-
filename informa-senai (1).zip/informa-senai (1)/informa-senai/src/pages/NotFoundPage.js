import {html} from '../utils/dom.js';
import {EmptyState} from '../components/ui.js';
export default async function NotFoundPage(){
  return {title:'Página não encontrada',description:'A página procurada não existe.',
    view:html`<div class="container">${EmptyState({level:1,title:'Página não encontrada',text:'O endereço pode ter mudado ou a publicação foi removida.',action:{label:'Voltar ao início',href:'/'}})}</div>`};
}
