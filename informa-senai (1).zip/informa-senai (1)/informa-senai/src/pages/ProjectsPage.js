import {html} from '../utils/dom.js';
import {getProjects} from '../services/projectService.js';
import {ProjectCard} from '../components/ProjectCard.js';
import {Breadcrumb} from '../components/ui.js';
export default async function ProjectsPage(){
  const projects=await getProjects();
  return {title:'Projetos Web de Alunos',description:'Projetos web desenvolvidos pelos estudantes dos cursos do SENAI.',
    view:html`<div class="container listing">${Breadcrumb([{label:'Início',href:'/'},{label:'Projetos'}])}
      <h1>Projetos Web de Alunos</h1><div class="grid">${projects.map(p=>ProjectCard(p))}</div></div>`};
}
