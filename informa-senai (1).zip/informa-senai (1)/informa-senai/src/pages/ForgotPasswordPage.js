import {html,$} from '../utils/dom.js';
import {requestPasswordReset,isValidEmail} from '../services/authService.js';
import {AuthShell,AuthSwitch} from '../components/AuthShell.js';
import {Field,Button,bindForm} from '../components/ui.js';

export default async function ForgotPasswordPage(){
  return {layout:'auth',title:'Recuperar senha',description:'Recupere o acesso à sua conta do IN-FORMA SENAI.',
    view:AuthShell({heading:'Recuperar senha',
      children:html`<form class="form" novalidate>
        ${Field({id:'email',label:'E-mail institucional',type:'email',placeholder:'Digite seu e-mail institucional',autocomplete:'username'})}
        <p class="form-error" role="alert" data-form-error></p><p class="form-success" role="status"></p>
        ${Button({label:'Enviar instruções',type:'submit'})}
      </form>
      ${AuthSwitch({text:'Lembrou a senha?',label:'Acessar conta',href:'/entrar'})}`}),
    mount(root){
      const form=$(root,'form');
      bindForm(form,{validate:d=>isValidEmail(d.email)?{}:{email:'Digite um e-mail válido.'},
        submit:async d=>{await requestPasswordReset(d.email);$(form,'.form-success').textContent='Se o e-mail estiver cadastrado, você receberá as instruções em instantes.';}});
    }};
}
