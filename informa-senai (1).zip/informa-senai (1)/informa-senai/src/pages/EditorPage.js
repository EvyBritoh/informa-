import {html,$} from '../utils/dom.js';
import {resolveImage} from '../assets/images.js';
import {ApiError} from '../services/http.js';
import {getNewsById,createNews,updateNews,deleteNews} from '../services/newsService.js';
import {getCategories} from '../services/categoryService.js';
import {uploadImage} from '../services/mediaService.js';
import {navigate} from '../router.js';
import {confirmDialog} from '../components/dialog.js';
import {Icon} from '../components/icons.js';
import {Field,bindForm,showFieldErrors} from '../components/ui.js';
import {NEWS_TYPES} from '../types.js';

/** Equivale ao "Modal - adicionar notícia" do wireframe (página dedicada com botão Voltar no mobile). */
export default async function EditorPage({params,user}){
  const id=params.id;
  const [cats,existing]=await Promise.all([getCategories(),id?getNewsById(id):null]);
  if(existing&&user.role!=='admin'&&!['rascunho','revisao'].includes(existing.status))throw new ApiError(403,'Este artigo já foi enviado e não pode mais ser editado.');
  const n=existing||{title:'',excerpt:'',content:'',category:{slug:''},type:'artigo',course:'',tags:[],image:''};
  const heading=id?'Editar notícia':'Adicionar notícia';
  return {
    layout:'panel',title:heading,description:'Editor de notícias e artigos.',
    view:html`<div class="container editor">
      <a class="back" href="/painel">${Icon('arrow-left',18)} Voltar</a>
      <h1>${heading}</h1>
      <form class="editor__form" novalidate>
        <div class="editor__main">
          ${Field({id:'title',label:'Título da notícia',value:n.title,attrs:'maxlength="140"'})}
          ${Field({id:'excerpt',label:'Resumo (aparece nos cards)',as:'textarea',rows:3,value:n.excerpt})}
          ${Field({id:'content',label:'Corpo da notícia (HTML)',as:'textarea',rows:14,value:n.content,hint:'Tags permitidas: p, h2–h4, ul, ol, li, strong, em, a, blockquote, br, img.'})}
        </div>
        <div class="editor__side">
          <div class="field" data-field="image">
            <span class="label" id="image-label">Imagens</span>
            <div class="dropzone"><img id="image-preview" src="${resolveImage(n.image)}" alt="Pré-visualização da imagem da notícia" width="640" height="360">
              <label class="btn btn--secondary" for="image-file">${Icon('upload',18)} Selecionar arquivo</label>
              <input class="sr-only" id="image-file" type="file" accept="image/*" aria-describedby="image-msg"><p class="field__hint">Máx. 5 MB</p></div>
            <input type="hidden" name="image" value="${n.image}">
            <p class="field__error" id="image-msg" role="alert"></p>
          </div>
          ${Field({id:'category',label:'Categoria',as:'select',value:n.category.slug,options:[{value:'',label:'Selecione…'},...cats.map(c=>({value:c.slug,label:c.label}))]})}
          ${Field({id:'type',label:'Tipo',as:'select',value:n.type,options:Object.entries(NEWS_TYPES).map(([value,label])=>({value,label}))})}
          ${Field({id:'course',label:'Curso',value:n.course,required:false})}
          ${Field({id:'tags',label:'Tags (separadas por vírgula)',value:n.tags.join(', '),required:false})}
        </div>
        <p class="form-error" role="alert" data-form-error></p>
        <div class="editor__actions">
          <button class="btn btn--primary" type="submit" value="post">Postar</button>
          <button class="btn btn--secondary" type="submit" value="draft">Salvar rascunho</button>
          <a class="btn btn--ghost" href="/painel">Cancelar</a>
          ${id&&html`<button class="btn btn--danger" type="button" data-action="delete">Deletar</button>`}
        </div>
      </form></div>`,
    mount(root){
      const form=$(root,'form'),file=$(root,'#image-file'),hidden=$(form,'[name=image]');
      file.addEventListener('change',async()=>{
        const f=file.files[0];if(!f)return;
        try{const url=await uploadImage(f);hidden.value=url;$(root,'#image-preview').src=url;showFieldErrors(form,{});}
        catch(e){showFieldErrors(form,{image:e.message});file.value='';}
      });
      bindForm(form,{
        validate:d=>({
          ...(d.title.trim().length<5&&{title:'O título precisa ter ao menos 5 caracteres.'}),
          ...(d.excerpt.trim().length<10&&{excerpt:'Escreva um resumo com ao menos 10 caracteres.'}),
          ...(d.content.trim().length<20&&{content:'O corpo precisa ter ao menos 20 caracteres.'}),
          ...(!d.category&&{category:'Escolha uma categoria.'})}),
        submit:async(d,submitter)=>{
          const payload={title:d.title,excerpt:d.excerpt,content:d.content,category:d.category,type:d.type,course:d.course,image:d.image,
            tags:d.tags.split(',').map(t=>t.trim()).filter(Boolean),status:submitter?.value==='draft'?'rascunho':'em_analise'};
          id?await updateNews(id,payload):await createNews(payload);
          navigate('/painel');
        }});
      $(root,'[data-action=delete]')?.addEventListener('click',async()=>{
        if(await confirmDialog('Deletar notícia','Esta ação não pode ser desfeita.','Deletar')){await deleteNews(id);navigate('/painel');}
      });
    }
  };
}
