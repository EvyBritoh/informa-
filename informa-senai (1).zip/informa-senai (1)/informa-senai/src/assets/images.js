// Único ponto de resolução de imagens. Troque aqui por CDN/storage quando houver backend.
const TONES=['#e84910','#1e1e1e','#b83a0b','#52525b','#c43a0a','#3f3f46'];
export function placeholderImage(i=0){
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 360"><rect width="640" height="360" fill="${TONES[i%TONES.length]}"/><g fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="10"><circle cx="460" cy="180" r="120"/><circle cx="460" cy="180" r="60"/><path d="M0 300 200 100M60 360 260 160"/></g></svg>`;
  return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
}
/** Aceita 'placeholder:N', URL absoluta/relativa ou data URL. */
export const resolveImage=src=>src?.startsWith('placeholder:')?placeholderImage(+src.slice(12)):src||placeholderImage(0);
