/** @typedef {{slug:string,label:string}} Category */
/** @typedef {{id:string,name:string,handle:string}} Author */
/** @typedef {'rascunho'|'em_analise'|'revisao'|'publicado'} NewsStatus */
/** @typedef {{id:string,title:string,slug:string,excerpt:string,content:string,image:string,category:Category,author:Author,course:string,type:'noticia'|'artigo',status:NewsStatus,publishedAt:string|null,submittedAt:string|null,tags:string[],featured:boolean,views:number,feedback:{text:string,reviewer:string,date:string}|null}} News */
/** @typedef {{id:string,name:string,email:string,role:'admin'|'escritor'}} User */
/** @typedef {{id:string,title:string,date:string}} AgendaEvent */
/** @typedef {{id:string,title:string,slug:string,kind:string,course:string,summary:string,image:string,url:string|null,author:Author}} Project */
/** @typedef {{items:any[],total:number,page:number,pageSize:number,totalPages:number}} Paginated */
export const STATUS={rascunho:'Rascunho',em_analise:'Em análise',revisao:'Em revisão',publicado:'Publicado'};
export const NEWS_TYPES={noticia:'Notícia',artigo:'Artigo'};
export const ROLES={admin:'Administrador',escritor:'Escritor'};
