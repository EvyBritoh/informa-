export const config={
  siteName:'IN-FORMA SENAI',
  edition:'// EDIÇÃO MENSAL . VOL 24',
  city:"Santa Bárbara d'Oeste",
  disclaimer:'*este site não é oficial do SENAI',
  useMock:true,            // dados de notícias/eventos/projetos. Autenticação NUNCA é simulada.
  apiBaseUrl:'/api',
  pageSize:6,
  maxImageBytes:5*1024*1024,
  institutionalDomains:[], // ex.: ['senai.br','aluno.senai.br'] para exigir domínio no cadastro; vazio = o backend decide
  storagePrefix:'informa:',
  nav:[
    {label:'Home',href:'/'},
    {label:'Últimas Notícias',href:'/noticias'},
    {label:'Artigos',href:'/artigos'},
    {label:'Projetos',href:'/projetos'}
  ]
};
