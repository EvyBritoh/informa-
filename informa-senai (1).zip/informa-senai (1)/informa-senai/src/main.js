import {initRouter} from './router.js';
import './routes.js';
import {shell} from './shell.js';
import {getContributors} from './services/authService.js';
shell.contributors=await getContributors().catch(()=>[]);
initRouter();
