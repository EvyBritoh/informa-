export function buildIcs(events){
  const esc=s=>s.replace(/[\\;,]/g,'\\$&').replace(/\n/g,'\\n');
  const stamp=new Date().toISOString().replace(/[-:]|\.\d{3}/g,'');
  return ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//IN-FORMA SENAI//PT','CALSCALE:GREGORIAN',
    ...events.flatMap(e=>['BEGIN:VEVENT',`UID:${e.id}@informa-senai`,`DTSTAMP:${stamp}`,`DTSTART;VALUE=DATE:${e.date.replaceAll('-','')}`,`SUMMARY:${esc(e.title)}`,'END:VEVENT']),
    'END:VCALENDAR'].join('\r\n');
}
export function downloadFile(name,content,type){
  const a=Object.assign(document.createElement('a'),{href:URL.createObjectURL(new Blob([content],{type})),download:name});
  document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
