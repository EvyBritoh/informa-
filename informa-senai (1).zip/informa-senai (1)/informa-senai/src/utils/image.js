/** Redimensiona e comprime no navegador (mock). Com backend, envie o arquivo original por multipart. */
export async function compressImage(file,{maxSide=1280,quality=.82}={}){
  const bmp=await createImageBitmap(file);
  const scale=Math.min(1,maxSide/Math.max(bmp.width,bmp.height));
  const c=Object.assign(document.createElement('canvas'),{width:Math.round(bmp.width*scale),height:Math.round(bmp.height*scale)});
  c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);
  return c.toDataURL('image/jpeg',quality);
}
