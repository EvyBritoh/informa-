const RAW=Symbol('raw');
const ESC={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
/** Marca uma string como HTML confiável (não escapar). */
export const raw=s=>({[RAW]:true,s:String(s)});
// Escapa tudo por padrão: dados do backend nunca viram HTML sem passar por raw()/sanitizeHtml().
const out=v=>Array.isArray(v)?v.map(out).join(''):v?.[RAW]?v.s:(v==null||v===false)?'':String(v).replace(/[&<>"']/g,c=>ESC[c]);
export const html=(strings,...vals)=>raw(strings.reduce((acc,s,i)=>acc+s+(i<vals.length?out(vals[i]):''),''));
export const $=(root,sel)=>root.querySelector(sel);
export const $$=(root,sel)=>[...root.querySelectorAll(sel)];
export const formatDate=(iso,opts={day:'2-digit',month:'2-digit',year:'numeric'})=>iso?new Intl.DateTimeFormat('pt-BR',{...opts,timeZone:'UTC'}).format(new Date(iso)):'';
export const todayLong=()=>new Intl.DateTimeFormat('pt-BR',{day:'numeric',month:'long',year:'numeric'}).format(new Date());
export const slugify=s=>s.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
export const initials=n=>n.split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
export const readingMinutes=h=>Math.max(1,Math.round(h.replace(/<[^>]+>/g,' ').split(/\s+/).filter(Boolean).length/200));
export function buildUrl(base,params={}){
  const q=new URLSearchParams(Object.entries(params).filter(([,v])=>v!==undefined&&v!==null&&v!==''));
  const s=q.toString();return s?`${base}?${s}`:base;
}
