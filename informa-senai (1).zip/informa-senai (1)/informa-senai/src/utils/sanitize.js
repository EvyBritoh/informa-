// Corpo das notícias é HTML (wireframe). Sanitiza por allowlist antes de renderizar.
// Quando houver backend, sanitize também no servidor.
const ALLOWED=new Set(['P','H2','H3','H4','UL','OL','LI','STRONG','B','EM','I','A','BR','BLOCKQUOTE','IMG','FIGURE','FIGCAPTION']);
const DROP=new Set(['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','FORM','INPUT']);
const SAFE={href:/^(https?:|\/|mailto:)/i,src:/^(https?:|\/|data:image\/(png|jpe?g|webp|gif);)/i};
function clean(el){
  [...el.children].forEach(c=>{
    clean(c);
    if(!ALLOWED.has(c.tagName)){DROP.has(c.tagName)?c.remove():c.replaceWith(...c.childNodes);return;}
    [...c.attributes].forEach(a=>{
      const ok=(c.tagName==='A'&&(a.name==='href'||a.name==='title'))||(c.tagName==='IMG'&&(a.name==='src'||a.name==='alt'));
      if(!ok||(SAFE[a.name]&&!SAFE[a.name].test(a.value.trim())))c.removeAttribute(a.name);
    });
    if(c.tagName==='A')c.setAttribute('rel','noopener noreferrer');
    if(c.tagName==='IMG')c.setAttribute('loading','lazy');
  });
}
export function sanitizeHtml(dirty=''){
  const doc=new DOMParser().parseFromString(`<body>${dirty}</body>`,'text/html');
  clean(doc.body);return doc.body.innerHTML;
}
