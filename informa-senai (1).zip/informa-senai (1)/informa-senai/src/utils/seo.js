import {config} from '../config.js';
const upsert=(sel,make)=>document.head.querySelector(sel)||document.head.appendChild(make());
const meta=(key,value,prop=false)=>{
  const attr=prop?'property':'name';
  upsert(`meta[${attr}="${key}"]`,()=>{const m=document.createElement('meta');m.setAttribute(attr,key);return m;}).setAttribute('content',value);
};
export function setMeta({title,description='',image,type='website',jsonLd}){
  const full=title?`${title} | ${config.siteName}`:`${config.siteName} — jornal dos estudantes do SENAI`;
  document.title=full;
  meta('description',description);
  meta('og:title',full,true);meta('og:description',description,true);meta('og:type',type,true);meta('og:site_name',config.siteName,true);
  if(image&&!image.startsWith('data:'))meta('og:image',new URL(image,location.origin).href,true);
  upsert('link[rel="canonical"]',()=>{const l=document.createElement('link');l.rel='canonical';return l;}).href=location.href;
  document.head.querySelectorAll('script[data-jsonld]').forEach(s=>s.remove());
  if(jsonLd){const s=document.createElement('script');s.type='application/ld+json';s.dataset.jsonld='';s.textContent=JSON.stringify(jsonLd);document.head.append(s);}
}
